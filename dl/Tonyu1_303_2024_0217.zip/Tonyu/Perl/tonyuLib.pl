package tonyuLib;
# Tonyu System ネットランキングCGIライブラリ
# Copyright 2002 Hoge- Ship

# 本ライブラリの使いかた
# 1. メインプログラムに次の行を挿入します
#   require 'tonyuLib.pl';
# 2. 次の行を実行します。 $passwordは、ネットランキング管理者パスワードです。
#    ランタイム作成時に入力したパスワードと同じものを渡してください。
#   $ok=&tonyuLib'makeRankParam($password);
#  この関数は、ランタイムから渡されてきたパラメータを
#  連想配列 %tonyuLib'r に代入します。
# 3. 戻り値($ok)を調べます。
#   戻り値が真であればパラメータは正しく渡されています
#  ランタイムの内容がユーザによって変更されていたり、ユーザがブラウザに直接パラメータを書いた場合は戻り値は偽になります。
# 4. 渡されたパラメータを参照します。
#  例)
#   $score=$tonyuLib'r{'score'};
#   $name=$tonyuLib'r{'name'};

1;

sub makeRankParam {
    local ($password)=@_;
    local (@s,$ph,$pl,$i,$j,$a);
    $pwd=&hashPass($password);
	
    if ($ENV{'REQUEST_METHOD'} eq "GET") {
	$_ = $ENV{'QUERY_STRING'};
    } elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
	read(STDIN, $_, $ENV{'CONTENT_LENGTH'});
    }
    @params=split(/&/);

    $ph=($pwd >> 16) & 65535;
    $pl=$pwd & 65535;
    $result=0;
    for ($i=0 ; $i<=$#params ; $i++) {
	($name,$val)=split(/=/,$params[$i]);
	$val =~ s/%(..)/pack("c", hex($1))/ge;
	if (not ($name eq 'ID')) {
	    $a=0;
	    @s=unpack("c*",$params[$i]);
	    $j=1;
	    foreach $sj (@s) {
		if (($j & 1)==0) {
		    $a=($a+$sj*$j*$ph) & 65535;
		}else {
		    $a=($a+$sj*$j*$pl) & 65535;
		}
		$j++;
             $a=($a*5) & 65535;
	    }
	    #print "$params[$i] $a $ph $pl<HR>";
	    $result=$result ^ $a;
	    $r{$name}=$val;
	} else {
	    $id=$val;
	}
    }
    if ($result==$id) {return "OK";}
    return 0;
}

sub hashPass {
    local($p)=@_;
    local(@dat)=unpack("c*",$p);
    local($l)=0;
    local($h)=0;
    local($i)=1;
    foreach $a (@dat) {
	$h=($h+$a*($i+17)*4387) & 65535;
	$l=($l+($a+1)*$i*3203) & 65535;
	$i++;
    }
#    print "$h   $l\n";
    $h*65536+$l;
}