#include <stdio.h>
#include <Windows.h>
#include "Mezonet.h"

main (){
	void *p1,*p2;
	int i;
	InitMezonet ();
	
	MZ_SetDelay (2000);
	MZ_LoadBGM ("Tulip.mzo");
	if (MZ_GetError()!=MZE_NoError) exit (0);

	p1=MZ_LoadSE ("SE1.wav");
	p2=MZ_LoadSE ("SE2.wav");
	
	MZ_PlayBGM ();

	for (i=0 ; i<2000 ; i++) {	
    	        MZ_Refresh ();
		Sleep (8);
		if (i%150==0) MZ_PlaySEPrio (p1,128);
		if (i%150==100) MZ_PlaySEPrio (p2,128);
		if (i==500) MZ_StopBGM ();
		if (i==600) MZ_OnOff (0);
		if (i==700) MZ_OnOff (1);
		if (i==800) MZ_PlayBGM ();

	}

}
