#include <stdio.h>
#include <Windows.h>

typedef enum {MZE_NoError,MZE_NotFound,MZE_BadFormat,MZE_Broken,
      MZE_Unavailable,MZE_Version} TMzError;

/*
Delphi Declarations

procedure MZ_StopBGM; stdcall;
function MZ_LoadSE (s:Pchar):Pointer; stdcall;
procedure MZ_PlaySE (p:Pointer;v:Integer); stdcall;
procedure MZ_PlaySEPrio (p:Pointer;v:Integer); stdcall;
function MZ_LoadBGM (s:PChar):byte; stdcall;
function MZ_PlayBGM:byte; stdcall;
function MZ_OnOff (b:byte):byte; stdcall;
function MZ_GetError:byte; stdcall;
procedure MZ_SetDelay (i:Integer); stdcall;
procedure MZ_SetBSize (i:Integer); stdcall;
procedure MZ_Refresh; stdcall;
function MZ_CurrentSE:Pointer; stdcall;
function MZ_Caption:PChar; stdcall;
function MZ_Version:Integer; stdcall;

*/
//##################

void  __stdcall MZ_StopBGM   (void);
void* __stdcall MZ_LoadSE    (char *);
void  __stdcall MZ_PlaySE    (void *,int);
void  __stdcall MZ_PlaySEPrio(void *,int);
byte  __stdcall MZ_LoadBGM   (char *);
byte  __stdcall MZ_PlayBGM   (void);
byte  __stdcall MZ_OnOff     (byte);
byte  __stdcall MZ_GetError  (void);
void  __stdcall MZ_SetDelay  (int);
void  __stdcall MZ_SetBSize  (int);
void  __stdcall MZ_Refresh   (void);
void* __stdcall MZ_CurrentSE (void);
char* __stdcall MZ_Caption   (void);
int   __stdcall MZ_Version   (void);

//##################

typedef void  (__stdcall *Fvv)   (void);
typedef void* (__stdcall *Fvpcp) (char *);
typedef void  (__stdcall *Fvvpi) (void *,int);
typedef byte  (__stdcall *Fbcp)  (char *);
typedef byte  (__stdcall *Fbv)   (void);
typedef byte  (__stdcall *Fbb)   (byte);
typedef void  (__stdcall *Fvi)   (int);
typedef void* (__stdcall *Fvpv)  (void);
typedef char* (__stdcall *Fcpv)  (void);
typedef int   (__stdcall *Fiv)  (void);

//##################

Fvv   P_StopBGM , P_Refresh;
Fvpcp P_LoadSE ;
Fvvpi P_PlaySE  ,P_PlaySEPrio;
Fbcp  P_LoadBGM;
Fbv   P_PlayBGM,P_GetError;
Fbb   P_OnOff;
Fvi   P_SetDelay , P_SetBSize ;
Fvpv  P_CurrentSE ;
Fcpv  P_Caption ;
Fiv   P_Version;

//##################

InitMezonet () {
      HINSTANCE h=LoadLibrary ("mezonet.dll");
//Fvv
      P_StopBGM=(Fvv)GetProcAddress(h,"MZ_StopBGM");
      P_Refresh=(Fvv)GetProcAddress(h,"MZ_Refresh");
//Fvpcp
      P_LoadSE=(Fvpcp)GetProcAddress(h,"MZ_LoadSE");
//Fvvpi
      P_PlaySE=(Fvvpi)GetProcAddress(h,"MZ_PlaySE");
      P_PlaySEPrio=(Fvvpi)GetProcAddress(h,"MZ_PlaySEPrio");
//Fbcp
      P_LoadBGM=(Fbcp)GetProcAddress(h,"MZ_LoadBGM");
//Fbv
      P_PlayBGM=(Fbv)GetProcAddress(h,"MZ_PlayBGM");
      P_GetError=(Fbv)GetProcAddress(h,"MZ_GetError");
//Fbb
      P_OnOff=(Fbb)GetProcAddress(h,"MZ_OnOff");
//Fvi
      P_SetDelay=(Fvi)GetProcAddress(h,"MZ_SetDelay");
      P_SetBSize=(Fvi)GetProcAddress(h,"MZ_SetBSize");
//Fvpv
      P_CurrentSE=(Fvpv)GetProcAddress(h,"MZ_CurrentSE");
//Fcpv
      P_Caption=(Fcpv)GetProcAddress(h,"MZ_Caption");
//Fiv
      P_Version=(Fiv)GetProcAddress(h,"MZ_Version");;
}

//##################

void  __stdcall MZ_StopBGM   (void) {
	(*P_StopBGM) ();
}

void* __stdcall MZ_LoadSE    (char *c) {
	return (*P_LoadSE) (c);
}

void  __stdcall MZ_PlaySE    (void *p,int i) {
	(*P_PlaySE) (p,i);
}

void  __stdcall MZ_PlaySEPrio(void *p,int i) {
	(*P_PlaySEPrio) (p,i);
}

byte  __stdcall MZ_LoadBGM   (char *c) {
	return (*P_LoadBGM) (c);
}

byte  __stdcall MZ_PlayBGM   (void) {
	return (*P_PlayBGM) ();
}
 
byte  __stdcall MZ_OnOff     (byte b) {
	return (*P_OnOff) (b);
}

byte  __stdcall MZ_GetError  (void) {
	return (*P_GetError) ();
}

void  __stdcall MZ_SetDelay  (int i) {
	(*P_SetDelay) (i);
}
void  __stdcall MZ_SetBSize  (int i) {
	(*P_SetBSize) (i);
}

void  __stdcall MZ_Refresh   (void) {
	(*P_Refresh) ();
}

void* __stdcall MZ_CurrentSE (void) {
	return (*P_CurrentSE) ();
}

char* __stdcall MZ_Caption   (void) {
      return (*P_Caption) ();
}

int __stdcall MZ_Version   (void) {
      return (*P_Version) ();
}

//##################


